/************************************************
	LAB JS BASE APP
************************************************/

INCLUDED LIBRARIES
- jquery
	
// WHAT THIS APP SHOULD DO


// KNOWN ISSUES
