package tsps;

/**
 * Simple rectangle class for TSPS bounding boxes, etc.
 */
public class Rectangle
{
	public float x, y, width, height;
};