# ofxSenselMorph2

Copy libSensel.dylib to /usr/lib 
