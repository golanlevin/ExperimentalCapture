/****************************************
	INSTALL
/****************************************

- install websocket-client
	- cd /path/to/tsps/examples/python/websocket-client/
	- python setup.py install