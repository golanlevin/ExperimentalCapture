Note
==============================
* openFrameworks examples are in the https://github.com/labatrockwell/ofxTSPSReceiver repository
* if you checked out this repository with submodules, it will be at openTSPS/addons/ofxTSPSReceiver
* note: you must still move ofxTSPSReceiver to openframeworks/addons OR move the examples to openframeworks/apps/myapps for them to compile