/*
 *  groupCollection.cpp
 *  openFrameworks
 *
 *  Created by theo on 10/09/2009.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "groupCollection.h"

