/*
 *  buttonState.h
 *  openFrameworks
 *
 *  Created by theo on 17/08/2009.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#pragma once

typedef enum{
	BUTTON_NONE,
	BUTTON_STARTING,
	BUTTON_STARTED,
	BUTTON_STOPPING,
	BUTTON_STOPPED
}buttonState;