extern void speakMe(const char * string);



